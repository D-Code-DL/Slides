function onclickButton(){
  var name = prompt("Enter your name");
  document.getElementById("userName").innerHTML = name;
}
